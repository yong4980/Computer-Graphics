#ifndef KMUCS_GRAPHICS_TRANSFORM_HPP
#define KMUCS_GRAPHICS_TRANSFORM_HPP

#include <cmath>
#include "vec.hpp"
#include "mat.hpp"
#include "operator.hpp"

namespace kmuvcl
{
    namespace math
    {
#ifndef M_PI
        const float M_PI = 3.14159265358979323846;
#endif

        template <typename T>
        mat<4, 4, T> translate(T dx, T dy, T dz)
        {
            mat<4, 4, T> translateMat;

            // TODO: Fill up this function properly
            vec<4, T> vec0(1,0,0,0);
            vec<4, T> vec1(0,1,0,0);
            vec<4, T> vec2(0,0,1,0);
            vec<4, T> vec3(dx,dy,dz,1);

            translateMat.set_ith_column(0,vec0);
            translateMat.set_ith_column(1,vec1);
            translateMat.set_ith_column(2,vec2);
            translateMat.set_ith_column(3,vec3);

            return translateMat;
        }

        template <typename T>
        mat<4, 4, T> rotate(T angle, T x, T y, T z)
        {
            mat<4, 4, T> rotateMat;
            // TODO: Fill up this function properly

            T temp = sqrt(x*x+y*y+z*z);
            x /= temp;
            y /= temp;
            z /= temp;

            angle = angle * M_PI / 180;

            vec<4, T> vec0((cos(angle) + x*x * (1-cos(angle))),
                          (y * x * (1-cos(angle)) + z * sin(angle)),
                          (z * x * (1-cos(angle)) - y * sin(angle)),
                          0
                          );
            vec<4,T> vec1((x * y * (1-cos(angle)) - z * sin(angle)),
                          (cos(angle) + y*y * (1-cos(angle))),
                          (z * y * (1-cos(angle)) + x * sin(angle)),
                          0
            );
            vec<4, T> vec2((x * z * (1-cos(angle)) + y * sin(angle)),
                          (y * z * (1-cos(angle)) - x * sin(angle)),
                          (cos(angle) + z*z * (1-cos(angle))),
                          0
            );
            vec<4, T> vec3(0,0,0,1);

            rotateMat.set_ith_column(0,vec0);
            rotateMat.set_ith_column(1,vec1);
            rotateMat.set_ith_column(2,vec2);
            rotateMat.set_ith_column(3,vec3);
            return rotateMat;
        }

        template<typename T>
        mat<4, 4, T> scale(T sx, T sy, T sz)
        {
            mat<4, 4, T> scaleMat;

            // TODO: Fill up this function properly
            vec <4, T> vec0(sx, 0, 0, 0);
            vec <4, T> vec1(0, sy, 0, 0);
            vec <4, T> vec2(0, 0, sz, 0);
            vec <4, T> vec3(0, 0, 0, 1);

            scaleMat.set_ith_column(0,vec0);
            scaleMat.set_ith_column(1,vec1);
            scaleMat.set_ith_column(2,vec2);
            scaleMat.set_ith_column(3,vec3);

            return scaleMat;
        }

        template<typename T>
        mat<4, 4, T> lookAt(T eyeX, T eyeY, T eyeZ, T centerX, T centerY, T centerZ, T upX, T upY, T upZ)
        {
            mat<4, 4, T> viewMat;


            // TODO: Fill up this function properly

            // make cam_z_axis vector
            T temp = sqrt((centerX-eyeX)*(centerX-eyeX) + (centerY-eyeY)*(centerY-eyeY) + (centerZ-eyeZ)*(centerZ-eyeZ));
            vec<3, T> cam_z_axis((eyeX-centerX) / temp, (eyeY-centerY) / temp, (eyeZ-centerZ) / temp);

            // make cam_x_axis vector
            vec<3, T> up(upX, upY, upZ);
            vec<3, T> temp_vec(cross(up, cam_z_axis));
            std::cout << cam_z_axis[0] << std::endl;

            temp = sqrt(temp_vec(0)*temp_vec(0) + temp_vec(1)*temp_vec(1) + temp_vec(2)*temp_vec(2));

            vec<3, T> cam_x_axis((temp_vec(0)/temp), (temp_vec(1)/temp), (temp_vec(2)/temp));

            // make cam_y_axis vector
            temp_vec = cross(cam_z_axis, cam_x_axis);
            temp = sqrt(temp_vec(0)*temp_vec(0) + temp_vec(1)*temp_vec(1) + temp_vec(2)*temp_vec(2));

            vec<3, T> cam_y_axis((temp_vec(0)/temp), (temp_vec(1)/temp), (temp_vec(2)/temp));

            // make viewMat
            vec<4, T> cam_x(cam_x_axis(0), cam_x_axis(1), cam_x_axis(2), 0);
            vec<4, T> cam_y(cam_y_axis(0), cam_y_axis(1), cam_y_axis(2), 0);
            vec<4, T> cam_z(cam_z_axis(0), cam_z_axis(1), cam_z_axis(2), 0);

            viewMat.set_ith_row(0, cam_x);
            viewMat.set_ith_row(1, cam_y);
            viewMat.set_ith_row(2, cam_z);
            vec<4, T> vec_temp((cam_x_axis(0)*eyeX+cam_x_axis(1)*eyeY+cam_x_axis(2)*eyeZ)==0?0:-(cam_x_axis(0)*eyeX+cam_x_axis(1)*eyeY+cam_x_axis(2)*eyeZ),
                               (cam_y_axis(0)*eyeX+cam_y_axis(1)*eyeY+cam_y_axis(2)*eyeZ)==0?0:-(cam_y_axis(0)*eyeX+cam_y_axis(1)*eyeY+cam_y_axis(2)*eyeZ),
                               (cam_z_axis(0)*eyeX+cam_z_axis(1)*eyeY+cam_z_axis(2)*eyeZ)==0?0:-(cam_z_axis(0)*eyeX+cam_z_axis(1)*eyeY+cam_z_axis(2)*eyeZ),
                               1
                              );
            viewMat.set_ith_column(3, vec_temp);

            return viewMat;
        }

        template<typename T>
        mat<4, 4, T> ortho(T left, T right, T bottom, T top, T nearVal, T farVal)
        {
            mat<4, 4, T> orthoMat;

            // TODO: Fill up this function properly
            vec<4, T> vec0(2/(right-left), 0, 0, 0);
            vec<4, T> vec1(0, 2/(top-bottom), 0, 0);
            vec<4, T> vec2(0, 0, -2/(farVal-nearVal), 0);
            vec<4, T> vec3(-(right+left)/(right-left), -(top+bottom)/(top-bottom), -(farVal+nearVal)/(farVal-nearVal), 1);

            orthoMat.set_ith_column(0, vec0);
            orthoMat.set_ith_column(1, vec1);
            orthoMat.set_ith_column(2, vec2);
            orthoMat.set_ith_column(3, vec3);

            return orthoMat;
        }

        template<typename T>
        mat<4, 4, T> frustum(T left, T right, T bottom, T top, T nearVal, T farVal)
        {
           mat<4, 4, T> frustumMat;

           // TODO: Fill up this function properly
           vec<4, T> vec0((2*nearVal)/(right-left), 0, 0, 0);
           vec<4, T> vec1(0, (2*nearVal)/(top-bottom), 0, 0);
           vec<4, T> vec2((right+left)/(right-left), (top+bottom)/(top-bottom), -(farVal+nearVal)/(farVal-nearVal), -1);
           vec<4, T> vec3(0, 0, (-2*farVal*nearVal)/(farVal-nearVal), 0);

           frustumMat.set_ith_column(0, vec0);
           frustumMat.set_ith_column(1, vec1);
           frustumMat.set_ith_column(2, vec2);
           frustumMat.set_ith_column(3, vec3);

           return frustumMat;
        }

        template<typename T>
        mat<4, 4, T> perspective(T fovy, T aspect, T zNear, T zFar)
        {
          T  right, top;

          // TODO: Fill up this function properly
          T angle = fovy * M_PI / 180 / 2;
          top = zNear * tan(angle);
          right = top * aspect;

          return frustum(-right, right, -top, top, zNear, zFar);
        }
    }
}
#endif
