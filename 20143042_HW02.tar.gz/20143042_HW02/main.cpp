// hello_world.cpp
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <ctime>
#include <cmath>
#include "transform.hpp"

int OFFSET = 7;
int COLOR = 1;   // 1=red, 2=green, 3=blue
int MIN_MAX =1; // 1 = 1/5   2 = 5/15   3 = 15/30
int RATIO = 2;
float INTERVAL = 0.8f;
float level_size[6] = { 0.0f, 1.0f, 3.0f, 7.0f, 15.0f, 31.0f };
int m = 1;
int pm = 0;

void init();
void mydisplay();
void draw_rectangle(float centerX, float centerY, float size);
void draw_rectangle_group(float centerX, float centerY, int level, int offset, float interval);
void extract_hilbert_vertex(float x0, float y0, float xis, float xjs, float yis, float yjs, int n, float** vertex, int level);
void draw_hilbert(float** vertex, int size);
void draw_hilbert_rectangle(int level);
void draw();
void create_GLU_menus();

void main_menus(int values);

GLuint create_shader_from_file(const std::string& filename, GLuint shader_type);
//shader에서 변수 만들면 여기에도 추가
GLuint program; // 쉐이더 프로그램 객체의 레퍼런스 값
GLint  loc_a_position;
GLint  loc_a_color;
GLint  loc_u_Model;
float dx = 0.0f, dy = 0.0f;

int main(int argc, char* argv[])
{
   srand((unsigned int)time(0));

   glutInit(&argc, argv);
   glutInitWindowSize(500, 500);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
   glutCreateWindow("Hello FreeGLUT");

   create_GLU_menus();
   init();

   glutDisplayFunc(mydisplay);
   glutMainLoop();

   return 0;
}

// GLSL 파일을 읽어서 컴파일한 후 쉐이더 객체를 생성하는 함수
GLuint create_shader_from_file(const std::string& filename, GLuint shader_type)
{
   GLuint shader = 0;
   shader = glCreateShader(shader_type);
   std::ifstream shader_file(filename.c_str());
   std::string shader_string;
   shader_string.assign(
      (std::istreambuf_iterator<char>(shader_file)),
      std::istreambuf_iterator<char>());

   const GLchar* shader_src = shader_string.c_str();
   glShaderSource(shader, 1, (const GLchar**)&shader_src, NULL);

   glCompileShader(shader);

   return shader;
}

void init()
{
   glewInit();

   // 정점 쉐이더 객체를 파일로부터 생성
   GLuint vertex_shader
      = create_shader_from_file("./shader/vertex.glsl", GL_VERTEX_SHADER);

   // 프래그먼트 쉐이더 객체를 파일로부터 생성
   GLuint fragment_shader
      = create_shader_from_file("./shader/fragment.glsl", GL_FRAGMENT_SHADER);

   // 쉐이더 프로그램 생성 및 컴파일
   program = glCreateProgram();
   glAttachShader(program, vertex_shader);
   glAttachShader(program, fragment_shader);
   glLinkProgram(program);

   //GPU에서의 위치 값 가져오기
   loc_a_position = glGetAttribLocation(program, "a_position");
   loc_a_color = glGetAttribLocation(program, "a_color");
   loc_u_Model = glGetUniformLocation(program, "u_Model");

   glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
}

void mydisplay()
{
   if (m == pm) return;
   m = pm;

   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   glUseProgram(program);

   draw();

   glUseProgram(0);

   glutSwapBuffers();
}

void draw()
{
   for (int k = 0; k<2; k++)
   {
      for (int i = 1; i <= 5; i++)
      {
         int num = pow(RATIO, i - 1);
         for (int j = 0; j<num; j++)
         {
            draw_hilbert_rectangle(i);
         }
      }
   }
}

void draw_hilbert_rectangle(int level)
{
   int size = pow(pow(2, level), 2);
   float** vertex = new float*[size];
   for (int i = 0; i<size; i++)
      vertex[i] = new float[2];

   float temp1 = (rand() % 30) * 0.01f - 0.15f;
   float temp2 = (rand() % 30) * 0.01f - 0.15f;

   extract_hilbert_vertex(-0.85f + temp1, -0.85f + temp2, 1.7f, 0.0f, 0.0f, 1.7f, level, vertex, level);
   //draw_hilbert(vertex, size);
   int num;
   switch (MIN_MAX)
   {
   case 1: num = rand() % 5 + 1; break;
   case 2: num = rand() % 11 + 5; break;
   case 3: num = rand() % 16 + 15; break;
   }

   for (int i = 0; i<num; i++)
   {
      int select = rand() % size;
      draw_rectangle_group(vertex[select][0], vertex[select][1], level, OFFSET, INTERVAL);
   }

   for (int i = 0; i<size; i++)
      delete[] vertex[i];
   delete[] vertex;
}


void draw_rectangle_group(float centerX, float centerY, int level, int offset, float interval)
{
   float size = 1 / level_size[level];
   int version = 0;
   for (int i = 0; i<offset; i++)
   {
      draw_rectangle(centerX, centerY, size);
      size *= interval;
   }

}

void draw_rectangle(float centerX, float centerY, float size)
{
   kmuvcl::math::mat4x4f model_matrix;
   kmuvcl::math::mat4x4f T, S;
   float colorR, colorG, colorB;
   float temp = rand() % 10;

   switch (COLOR)
   {
     case 1 : if(temp<1) { colorR = 1.0f; colorG = 0.0f; colorB = 0.0f; } // 기본 빨강
              else if(temp<4) { colorR = rand()%20 * 0.01f + 0.8f; colorG = rand()%20 * 0.01f; colorB = rand()%20 * 0.01f; } // 진한 빨강
              else if(temp<6) { colorR = 1.0f; colorG = rand()%40 * 0.01f; colorB = rand()%40 * 0.01f; } // 빨강
              else if(temp<8) { colorR = 1.0f; colorG = rand()%20 * 0.01f + 0.8f; colorB = 0.15f; } // 노랑
              else { colorR = 1.0f; colorG = rand()%30 * 0.01f + 0.4f; colorB = 0.1f; } // 주황
              break;

     case 2 : if(temp<1) { colorR = rand()%30 * 0.01f + 0.3f; colorG = rand()%10 * 0.01f+ 0.7f; colorB = 1.0f; } // 하늘색
              else if(temp<3) { colorR = rand()%20 * 0.01f + 0.6f; colorG = 1.0f; colorB = rand()%10 * 0.01f; } // 초록 형광
              else if(temp<7) { colorR = rand()%70 * 0.01f; colorG = 1.0f; colorB = rand()%70 * 0.01f; } // 초록
              else { colorR = rand()%20 * 0.01f; colorG = 0.7f; colorB = rand()%20 * 0.01f; } //진한 초폭
              break;

     case 3 : if(temp<3) { colorR = rand()%30 * 0.01f + 0.3f; colorG = rand()%10 * 0.01f+ 0.7f; colorB = 1.0f; } // 하늘색
              else if(temp<5) { colorR = rand()%20 * 0.01f; colorG = rand()%20 * 0.01f; colorB = 0.7f; } // 진한 파랑
              else if(temp<8) { colorR = rand()%20 * 0.01f; colorG = rand()%20 * 0.01f; colorB = 1.0f; } // 파랑
              else if(temp<9) { colorR = 0.0f; colorG = 0.0f; colorB = 0.0f; } // 검은색
              else { colorR = 1.0f; colorG = rand()%10 * 0.01f + 0.9f; colorB = 0.5f; } //노랑
              break;

     case 4 : if(temp<2) { colorR = rand()%10 * 0.01f + 0.5f; colorG = rand()%10 * 0.01f; colorB = 1.0f; } //보라색
             else if(temp<4) { colorR = 1.0f; colorG = rand()%20 * 0.01f + 0.8f; colorB = rand()%20 * 0.01f; } //노란색
             else if(temp<6) { colorR = 1.0f; colorG = rand()%30 * 0.01f + 0.4f; colorB = 0.1f; } // 주황색
             else if(temp<8) { colorR = rand()%10 * 0.01f; colorG = rand()%10 * 0.01f; colorB = rand()%10 * 0.01f + 0.5f; } // 남색
             else { colorR = rand()%30*0.01f; colorG = rand()%10 * 0.01f + 0.7f; colorB = 1.0f; } //하늘색
             break; // 혼합
   }

   float position[] = {
      -0.4f, -0.4f, 0.0f, 1.0f,
      0.4f, -0.4f, 0.0f, 1.0f,
      0.4f,  0.4f, 0.0f, 1.0f,
      0.4f,  0.4f, 0.0f, 1.0f,
      -0.4f,  0.4f, 0.0f, 1.0f,
      -0.4f, -0.4f, 0.0f, 1.0f,
   };

   float color[] = {
      colorR, colorG, colorB, 1.0f,
      colorR, colorG, colorB, 1.0f,
      colorR, colorG, colorB, 1.0f,
      colorR, colorG, colorB, 1.0f,
      colorR, colorG, colorB, 1.0f,
      colorR, colorG, colorB, 1.0f,
   };

   T = kmuvcl::math::translate(centerX, centerY, 0.0f);
   S = kmuvcl::math::scale(size, size, 1.0f);
   model_matrix = T * S;

   glUniformMatrix4fv(loc_u_Model, 1, GL_FALSE, model_matrix);
   glVertexAttribPointer(loc_a_position, 4, GL_FLOAT, GL_FALSE, 0, position);
   glVertexAttribPointer(loc_a_color, 4, GL_FLOAT, GL_FALSE, 0, color);

   glEnableVertexAttribArray(loc_a_color);
   glEnableVertexAttribArray(loc_a_position);

   glDrawArrays(GL_TRIANGLES, 0, 6 /* 정점개수 */);

   glDisableVertexAttribArray(loc_a_color);
   glDisableVertexAttribArray(loc_a_position);

}

void extract_hilbert_vertex(float x0, float y0, float xis, float xjs, float yis, float yjs, int n, float** vertex, int level)
{
   static int index = 0;

   if (n <= 0)
   {
      // n이 1일때 4개 점중심값나옴 (x0+(xis+yis)/2, y0+(xjs+yjs)/2)
      dx = x0 + (xis + yis) / 2;
      dy = y0 + (xjs + yjs) / 2;
      vertex[index][0] = dx;
      vertex[index][1] = dy;
      index++;
   }
   else
   {
      extract_hilbert_vertex(x0, y0, yis / 2, yjs / 2, xis / 2, xjs / 2, n - 1, vertex, level);
      extract_hilbert_vertex(x0 + xis / 2, y0 + xjs / 2, xis / 2, xjs / 2, yis / 2, yjs / 2, n - 1, vertex, level);
      extract_hilbert_vertex(x0 + xis / 2 + yis / 2, y0 + xjs / 2 + yjs / 2, xis / 2, xjs / 2, yis / 2, yjs / 2, n - 1, vertex, level);
      extract_hilbert_vertex(x0 + xis / 2 + yis, y0 + xjs / 2 + yjs, -yis / 2, -yjs / 2, -xis / 2, -xjs / 2, n - 1, vertex, level);
   }
   if (index >= (pow(pow(2, level), 2)))
      index = 0;


}

void draw_hilbert(float** vertex, int size)
{
   float position[] = {
      0.0f, 0.0f, 0.0f, 1.0f,
      0.0f, 0.0f, 0.0f, 1.0f,
   };

   float color[] = {
      1.0f, 0.0f, 0.0f, 1.0f,
      1.0f, 0.0f, 0.0f, 1.0f,
   };

   for (int i = 0; i<size - 1; i++)
   {
      position[0] = vertex[i][0]; position[1] = vertex[i][1];
      position[4] = vertex[i + 1][0]; position[5] = vertex[i + 1][1];

      kmuvcl::math::mat4x4f model_matrix = kmuvcl::math::translate(0.0f, 0.0f, 0.0f);
      glUniformMatrix4fv(loc_u_Model, 1, GL_FALSE, model_matrix);

      glVertexAttribPointer(loc_a_position, 4, GL_FLOAT, GL_FALSE, 0, position);
      glVertexAttribPointer(loc_a_color, 4, GL_FLOAT, GL_FALSE, 0, color);

      glEnableVertexAttribArray(loc_a_color);
      glEnableVertexAttribArray(loc_a_position);

      glDrawArrays(GL_LINES, 0, 2);

      glDisableVertexAttribArray(loc_a_color);
      glDisableVertexAttribArray(loc_a_position);
   }
}

void main_menus(int values)
{
   switch (values)
   {
   case 1: OFFSET = 7; m++; break;
   case 2: OFFSET = 5; m++; break;
   case 3: OFFSET = 3; m++; break;
   case 4: MIN_MAX = 1; m++; break;
   case 5: MIN_MAX = 2; m++; break;
   case 6: MIN_MAX = 3; m++; break;
   case 7: RATIO = 2; m++; break;
   case 8: RATIO = 3; m++; break;
   case 9: RATIO = 5; m++; break;
   case 10 : COLOR = 1; m++; break;
   case 11 : COLOR = 2; m++; break;
   case 12 : COLOR = 3; m++; break;
   case 13 : COLOR = 4; m++; break;
   case 14: glClearColor(1.0f, 1.0f, 1.0f, 1.0f); m++; break;
   case 15: glClearColor(0.0f, 0.0f, 0.0f, 1.0f); m++; break;
   case 16: glClearColor(0.5f, 0.5f, 0.5f, 1.0f); m++; break;
   case 17: m++; break;
   }
   glutPostRedisplay();
}
void create_GLU_menus()
{
   GLint offsetMenu = glutCreateMenu(main_menus);
   glutAddMenuEntry("OFFSET : 7", 1);
   glutAddMenuEntry("OFFSET : 5", 2);
   glutAddMenuEntry("OFFSET : 3", 3);

   GLint min_maxMenu = glutCreateMenu(main_menus);
   glutAddMenuEntry("MIN/MAX : 1/5", 4);
   glutAddMenuEntry("MIN/MAX : 5/15", 5);
   glutAddMenuEntry("MIN/MAX : 15/30", 6);

   GLint ratioMenu = glutCreateMenu(main_menus);
   glutAddMenuEntry("RATIO : 2", 7);
   glutAddMenuEntry("RATIO : 3", 8);
   glutAddMenuEntry("RATIO : 5", 9);

   GLint colorMenu = glutCreateMenu(main_menus);
   glutAddMenuEntry("RED", 10);
   glutAddMenuEntry("GREEN", 11);
   glutAddMenuEntry("BLUE", 12);
   glutAddMenuEntry("MIXED", 13);

   GLint backMenu = glutCreateMenu(main_menus);
   glutAddMenuEntry("White Background", 14);
   glutAddMenuEntry("Black Background", 1);
   glutAddMenuEntry("Gray Background", 16);

   glutCreateMenu(main_menus);
   glutAddMenuEntry("New Picture", 17);

   glutAddSubMenu("BACKGROUND", backMenu);
   glutAddSubMenu("COLOR", colorMenu);
   glutAddSubMenu("OFFSET", offsetMenu);
   glutAddSubMenu("MIN/MAX", min_maxMenu);
   glutAddSubMenu("RATIO", ratioMenu);

   glutAttachMenu(GLUT_RIGHT_BUTTON);
}
