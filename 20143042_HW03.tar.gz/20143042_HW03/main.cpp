// Defines the entry point for the console application.
//
#include <GL/glew.h>
#include <GL/freeglut.h>

#include <iostream>
#include <string>
#include <fstream>

#include "Object.h"
#include "Camera.h"
#include "Shader.h"

#include "transform.hpp"

void init();
void display();
void reshape(int, int);
void idle();
void keyboard(unsigned char, int, int);
void special(int, int, int);

GLuint		program;

GLint			loc_a_vertex;
GLint			loc_u_pvm_matrix;

kmuvcl::math::mat4x4f mat_PVM;

Object		g_desk, g_fan, g_sofa, g_tv;  // furniture
Camera		g_camera;											// viewer (you)

float rotating = 0.0f, rotate_v = 3.0f;
float rotate = 2.0f, fast = 0.1f;

int main(int argc, char* argv[])
{
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
  glutInitWindowPosition(100, 100);
  glutInitWindowSize(640, 640);
  glutCreateWindow("Modeling & Navigating Your Studio");

  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutKeyboardFunc(keyboard);
  glutSpecialFunc(special);
  glutIdleFunc(idle);

  if (glewInit() != GLEW_OK)
  {
    std::cerr << "failed to initialize glew" << std::endl;
	   return -1;
  }

  init();

  glutMainLoop();

  return 0;
}

void init()
{
  g_desk.load_simple_obj("./data/desk.obj");
  g_fan.load_simple_obj("./data/fan.obj");
  g_sofa.load_simple_obj("./data/sofa.obj");
  g_tv.load_simple_obj("./data/tv.obj");

  glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

  glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);    // for wireframe rendering

	program = Shader::create_program("./shader/simple.vert", "./shader/simple.frag");

	loc_u_pvm_matrix	= glGetUniformLocation(program, "u_pvm_matrix");

	loc_a_vertex			= glGetAttribLocation(program, "a_vertex");
}

void display()
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glUseProgram(program);

	// Camera setting
	kmuvcl::math::mat4x4f   mat_Proj, mat_View, mat_Model;

	// camera extrinsic param
	mat_View = kmuvcl::math::lookAt(
		g_camera.position()(0), g_camera.position()(1), g_camera.position()(2),				// eye position
		g_camera.center_position()(0), g_camera.center_position()(1), g_camera.center_position()(2), // center position
		g_camera.up_direction()(0), g_camera.up_direction()(1), g_camera.up_direction()(2)			// up direction
		);
	// camera intrinsic param
	mat_Proj = kmuvcl::math::perspective(g_camera.fovy(), 1.0f, 0.001f, 10000.0f);

	//mat_Model = kmuvcl::math::mat4x4f(1.0f);
  //mat_PVM = mat_Proj*mat_View*mat_Model;
  //glUniformMatrix4fv(loc_u_pvm_matrix, 1, false, mat_PVM);

	// TODO: draw furniture by properly transforming each object
  kmuvcl::math::mat4x4f  transMat, rotateMat, scaleMat;
  //desk
  transMat = kmuvcl::math::translate(-5.0f, 0.0f, 0.0f);
  scaleMat = kmuvcl::math::scale(1.5f, 1.5f, 1.5f);
  mat_Model = transMat * scaleMat;
  mat_PVM = mat_Proj*mat_View*mat_Model;

  glUniformMatrix4fv(loc_u_pvm_matrix, 1, false, mat_PVM);
	g_desk.draw(loc_a_vertex);

  //fan
  transMat = kmuvcl::math::translate(0.0f, 5.0f, 0.0f);
  rotateMat = kmuvcl::math::rotate(rotating, 0.0f, 1.0f, 0.0f);
  scaleMat = kmuvcl::math::scale(1.5f, 1.5f, 1.5f);
  mat_Model = transMat * rotateMat * scaleMat;
  mat_PVM = mat_Proj*mat_View*mat_Model;

  glUniformMatrix4fv(loc_u_pvm_matrix, 1, false, mat_PVM);
	g_fan.draw(loc_a_vertex);

  //sofa
  transMat = kmuvcl::math::translate(0.0f, 0.0f, 5.0f);
  rotateMat = kmuvcl::math::rotate(180.0f, 0.0f, 1.0f, 0.0f);
  scaleMat = kmuvcl::math::scale(1.5f, 1.5f, 1.5f);
  mat_Model = transMat * rotateMat * scaleMat;
  mat_PVM = mat_Proj*mat_View*mat_Model;

  glUniformMatrix4fv(loc_u_pvm_matrix, 1, false, mat_PVM);
	g_sofa.draw(loc_a_vertex);

  //tv
  transMat = kmuvcl::math::translate(0.0f, 0.0f, -5.0f);
  scaleMat = kmuvcl::math::scale(2.0f, 2.0f, 2.0f);
  mat_Model = transMat * scaleMat;
  mat_PVM = mat_Proj*mat_View*mat_Model;

  glUniformMatrix4fv(loc_u_pvm_matrix, 1, false, mat_PVM);
	g_tv.draw(loc_a_vertex);
  ////////////////////////////////////////////////////////////
	glUseProgram(0);
	Shader::check_gl_error("draw");

  glutSwapBuffers();
}

void reshape(int width, int height)
{
	glViewport(0, 0, width, height);
}

void keyboard(unsigned char key, int x, int y)
{
  // TODO: properly handle keyboard event
  if(key =='a' || key =='A'){
    g_camera.rotate_left(rotate);
    glutPostRedisplay();
  }
  else if(key =='d' || key =='D'){
    g_camera.rotate_right(rotate);
    glutPostRedisplay();
  }

  if(key == 'z' || key =='Z'){
    rotate += 0.5f;
  }
  else if(key == 'x' || key == 'X'){
    rotate -= 0.5f;
    if(rotate < 0.0f)
      rotate = 0.0f;
  }
  else if(key == 'c' || key == 'C'){
    fast += 0.01f;
  }
  else if(key == 'v' || key == 'V'){
    fast -= 0.01f;
    if(fast < 0.0f)
      fast = 0.0f;
  }
  else if(key == 'o' || key == 'O'){
    rotate_v += 1.0f;
    glutPostRedisplay();
  }
  else if(key == 'p' || key == 'P'){
    rotate_v -= 1.0f;
    if(rotating < 0.0f)
      rotate_v = 0.0f;
      glutPostRedisplay();
  }

  glutPostRedisplay();
}

void special(int key, int x, int y)
{
	// TODO: properly handle special keyboard event
  switch (key){
    case GLUT_KEY_UP:
      g_camera.move_forward(fast);
      glutPostRedisplay();
      break;
    case GLUT_KEY_DOWN:
      g_camera.move_backward(fast);
      glutPostRedisplay();
      break;
    case GLUT_KEY_LEFT:
      g_camera.move_left(fast);
      glutPostRedisplay();
      break;
    case GLUT_KEY_RIGHT:
      g_camera.move_right(fast);
      glutPostRedisplay();
      break;
  }
  glutPostRedisplay();
}

void idle()
{
  // TODO: update your variables in idle time
  rotating += rotate_v;
  glutPostRedisplay();
}
